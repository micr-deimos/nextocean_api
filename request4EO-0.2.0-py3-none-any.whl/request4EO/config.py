Config = {
    "identity4EO": {
      "identity4EO-url": "https://triple-a.services4eo.com/oxauth/restv1/token",
      "identity4EO-client-id": "c1d64a5a-b11c-45b5-a9e6-170fbc7572b9",
      "identity4EO-client-secret": "stor34E0!Pwd"
    },

  "tokens": {
    "access-token": "f39f32a6-a646-45c8-a2a2-3026e855e65a",
    "api-key-token": "4de969a4-083d-48aa-aa22-27478ee8b28b"},
    
  # refresh-token = 
  #ARIA2 = 9ec171e8-9609-4f5c-b9e3-cea4f35862f5
  #ARIA3 = f285f8a3-d741-4fba-b4a7-93d27d2a6247
  #NextLand = 8c29db56-2cd0-4fa4-b9d6-84c2f15749c6
  #NextOcean = 4de969a4-083d-48aa-aa22-27478ee8b28b
  #Store4EO = ae03ec27-71ac-45c3-817c-4a5334edcfec

  "request4EO": {
    "request4EO-url": "https://api.services4eo.com/request/v1"
  }
}