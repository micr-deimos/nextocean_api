
This python package is made for use of the request service API,
You should create the object from the class requestServiceAPI and make the login with the function "login(<username>,<password>) to use the library."

To use the API, call one of the functions listed bellow:
-get_services_list(self) - returns the list of all available services ids
-get_service_description(self,service_id) - returns the input parameters of the service
-get_service(self,service_id) - get all the available information about the service
-order_service(self,service_id, service_parameters) - place an order of a service, needs the input parameters. 
-get_order(self, order_id) - return the order information
-get_order_products(self, order_id) - returns the download links from the orders of a service.

To perform an order, the user must insert the inputs in the following format:
service_parameters = {
    "aoi": "<area in WKT>",
    "beginAt": "<begin date in format YYYY-mm-ddTHH:MM>",
    "endAt": "<end date in format YYYY-mm-ddTHH:MM>",

    #Each service specific inputs should be formated in a list of dictionaries like this: 

    "inputs": [{
                    "identifier": "<parameter_identifier_1>",
                    "value": "<parameter_value_1>"
                    },
                {
                    "identifier":"<parameter_identifier_2>",
                    "value":"<parameter_value_2>"
                    }]
    }


Example "inputs" for each NextLand service:

"inputs": [{"identifier": "output_format","value":"JSON"}],
"serviceID": "VEGETATION_WATER_CONTENT___NORMALIZED_DIFFERENCE_INFRARED_INDEX"

"inputs":[{"identifier":"output_format","value":"JSON"}],
"serviceID":"VEGETATION_WATER_CONTENT___NORMALIZED_DIFFERENCE_WATER_INDEX"

"inputs":[{"identifier":"output_format","value":"JSON"}],
"serviceID":"VEGETATION_WATER_CONTENT___MOISTURE_STRESS_INDEX"

"inputs":[{"identifier":"output_format","value":"JSON"}],
"serviceID":"VEGETATION_INDICES___NORMALIZED_DIFFERENCE_VEGETATION_INDEX"

"inputs":[{"identifier":"biopar_type","value":"FAPAR"},{"identifier":"output_format","value":"JSON"}],
"serviceID":"VEGETATION_INDICES___BIOPHYSICAL_PARAMETERS"

"inputs":[{"identifier":"biopar_type","value":"FAPAR"},{"identifier":"output_format","value":"JSON"}],
"serviceID":"VEGETATION_INDICES___CROPSAR"

"inputs":[{"identifier":"output_format","value":"JSON"}],
"serviceID":"CROP_PHENOLOGY___HARVEST_DETECTION"

(currently has some problems)
"inputs":[{"identifier":"output_format","value":"JSON"}],
"serviceID":"CROP_TYPE_CLASSIFICATION"

"inputs":[{"identifier":"output_format","value":"JSON"}],
"serviceID":"ANOMALY_DETECTION___REGIONAL_BENCHMARKING"

"inputs":[{"identifier":"output_format","value":"JSON"}],
"serviceID":"BIOMASS_PRODUCTION"

(The Area Of Interest of this service has to be a point)
"inputs":[{"identifier":"service","value": "VANMSITS"}],
"serviceID":"SOIL_MOISTURE___POINT_TIME_SERIES"

"inputs":[{"identifier":"service","value": "VANMSIGD"}],
"serviceID":"SOIL_MOISTURE___GRIDDED_DATA"

"inputs":[{"identifier":"timeseries","value": "mean"}],
"serviceID":"CROP_WATER_NEEDS_INDEX"

"inputs":[{"identifier":"timeseries","value": "mean"}],
"serviceID":"ACTUAL_EVAPOTRANSPIRATION"

"inputs":[{"identifier":"timeseries","value": "mean"}],
"serviceID":"POTENTIAL_EVAPOTRANSPIRATION"

"inputs":[{"identifier":"timeseries","value": "mean"}],
"serviceID":"CROP_WATER_NEEDS___WATER_DEFICIT"

"inputs":[{"identifier":"service_id","value": "DME_MKFC"}],
"serviceID":"DEIMOS_FOREST_CLASSIFICATION_SERVICE___FINLAND"

"inputs":[{"identifier":"service_id","value": "DME_DME_STFC"}],
"serviceID":"DEIMOS_FOREST_CLASSIFICATION_SERVICE___PORTUGAL"

"inputs":[{"identifier":"service_id","value": "DME_FDFC"}],
"serviceID":"DEIMOS_FOREST_CLASSIFICATION_SERVICE___ROMANIA"

"inputs":[{"identifier":"biopar_type","value":"FAPAR"},{"identifier":"output_format","value":"JSON"}],
"serviceID":"TREE_HEALTH_INDICES___BIO_PHYSICAL_PARAMETERS__CCC__FAPAR__LAI__FCOVER_"

"inputs":[{"identifier":"output_format","value":"JSON"}],
"serviceID":"TREE_HEALTH_INDICES___NORMALIZED_DIFFERENCE_VEGETATION_INDEX"

"inputs":[{"identifier":"threshold","value":"0.5"},{"identifier":"raw","value":"False"},{"identifier":"output_format","value":"JSON"}],
"serviceID":"ANOMALY_DETECTION___YIELD_POTENTIAL_MAPS"

"inputs":[{"identifier":"output_format","value":"GTiff"}],
"serviceID":"ANOMALY_DETECTION___VARIABILITY_MAPS"

"inputs":[{"identifier":"bundle","value":"TIME_SERIES"},
	{"identifier":"biopar_biopar_type","value":"FAPAR"},
	{"identifier":"cropsar_biopar_type","value":"FCOVER"},
	{"identifier":"output_format","value":"JSON"}],
"serviceID":"SUPPORT_TO_IRRIGATION___TIME_SERIES"

"inputs":[{"identifier":"bundle","value":"SPATIAL_ANALYSIS"},
	{"identifier":"biopar_biopar_type","value":"FAPAR"},
	{"identifier":"output_format","value":"GTiff"}],
"serviceID":"SUPPORT_TO_IRRIGATION___SPATIAL_ANALYSIS"

"inputs":[{"identifier":"app_id","value":"FCD_SAVI"},
	  {"identifier":"app_name","value":"Forest Change Detection"},
	  {"identifier":"app_version","value":"1.0.0"},
	  {"identifier":"organization_name","value":"Deimos Space UK Ltd."},
	  {"identifier":"app_description","value":"Forest change detection using SAVI index"},
	  {"identifier":"sensor","value":"sentinel2"},
   	  {"identifier":"output_data_type","value":"float32"},
	  {"identifier":"START_TIME_PARAMETER","value":"2020-07-02 00:00:00"},
	  {"identifier":"STOP_TIME_PARAMETER","value":"2020-07-03 00:00:00"}]
"serviceID":"FOREST_CHANGE_DETECTION_USING_SAVI_INDEX"

(currently has some problems)
"inputs":[{"identifier":"app_id","value":"FFD_DNBR"},
	  {"identifier":"app_name","value":"Forest Fire Detection"},
	  {"identifier":"app_version","value":"1.0.0"},
	  {"identifier":"organization_name","value":"Deimos Space UK Ltd."},
	  {"identifier":"app_description","value":"Monitoring burn scars using differential normalised burn ratio (DNBR)."},
	  {"identifier":"sensor","value":"sentinel2"},
   	  {"identifier":"output_data_type","value":"float32"},
	  {"identifier":"START_TIME_PARAMETER","value":"2020-07-02 00:00:00"},
	  {"identifier":"STOP_TIME_PARAMETER","value":"2020-07-03 00:00:00"}],
"serviceID":"FOREST_FIRE_DETECTION"


"inputs":[{"identifier":"app_id","value":"FDD_TVI"},
	  {"identifier":"app_name","value":"Forest Density Detection"},
	  {"identifier":"app_version","value":"1.0.0"},
	  {"identifier":"organization_name","value":"Deimos Space UK Ltd."},
	  {"identifier":"app_description","value":"Forest density detection using TVI index"},
	  {"identifier":"sensor","value":"sentinel2"},
   	  {"identifier":"output_data_type","value":"float32"},
	  {"identifier":"START_TIME_PARAMETER","value":"2020-07-02 00:00:00"},
	  {"identifier":"STOP_TIME_PARAMETER","value":"2020-07-03 00:00:00"}],
"serviceID":"FOREST_DENSITY_DETECTION_USING_TVI_INDEX"