import json
import requests
import urllib.parse
import os

from request4EO.config import Config

class requestServiceAPI:
    def __init__(self):
        """Python Client API for Nextland backend.
        """

        self.config = Config

        self.x_api_key = self.config['tokens']['api-key-token']
        self.base_url = self.config['request4EO']['request4EO-url']

    def _build_authentication_header(self):
        authentication_header = {
            'x-api-key': f'{self.x_api_key}',
            'Authorization': f'Bearer {self.access_token}'
        }
        return authentication_header

    def login(self, user, password):
        """Authenticate a user to the backend using basic username and password.

        Parameters
        ----------
        user : str
            Username
        password : str
            Password
        """
        url = self.config['identity4EO']['identity4EO-url']
        client_id=self.config['identity4EO']['identity4EO-client-id']
        client_secret=self.config['identity4EO']['identity4EO-client-secret']
        
        enconded_user=urllib.parse.quote_plus(user)
        encoded_password=urllib.parse.quote_plus(password)
        access_token = self.config['tokens']['access-token']

        payload='grant_type=password&scope=openid%20profile%20gsc4eo%20email%20user_name&scope=storage&client_id={}&client_secret={}&username={}&password={}'.format(client_id,client_secret,enconded_user,encoded_password)
        headers = {'Authorization': 'Bearer {}'.format(access_token),
    'Content-Type': 'application/x-www-form-urlencoded'}

        response = requests.request("POST", url, headers=headers, data=payload)

        #print(response.status_code)
        self.config['tokens']['access-token'] = json.loads(response.text)["access_token"]
        self.config['tokens']['refresh-token'] = json.loads(response.text)["refresh_token"]
        self.access_token = self.config['tokens']['access-token']
        self.refresh_token = self.config['tokens']['refresh-token']
        return self.access_token, self.refresh_token


    def get_services_list(self, free_text=None):
        """Retrieve the list of available service IDs

        Parameters
        ----------
        free_text : str, optional
            Free text query, by default None

        Returns
        -------
        List
            List of available service IDs
        """
        service_list={}
        url = "{}/services".format(self.base_url)

        payload={}
        headers = self._build_authentication_header()

        response = requests.request("GET", url, headers=headers, data=payload)

        response_dict = json.loads(response.text)
        for service in response_dict['services']:
            service_id = service['identifier']
            service_list.update({service_id: service['title']})
        return service_list


    def get_service_description(self, service_id):
        """Retrieve input parameters of the service.

        Parameters
        ----------
        service_id : str
            Service ID

        """
        url = "{}/services/{}/description".format(self.base_url,service_id)

        payload={}
        headers = self._build_authentication_header()

        response = requests.request("GET", url, headers=headers, data=payload)
        response.raise_for_status()
        return json.loads(response.text)

    def _get_service_header(self, service_id):
        """_summary_

        Parameters
        ----------
        service_id : _type_
            _description_
        """
        url = f"{self.base_url}/services/{service_id}"

        payload={}
        headers = self._build_authentication_header()

        response = requests.request("GET", url, headers=headers, data=payload)
        response.raise_for_status()
        return json.loads(response.text)

    def get_service(self,service_id):
        """Get full information of the service, including name, description,
        allowed areas and time intervals, provider details, and required / optional
        input parameters

        Parameters
        ----------
        service_id : str
            Service ID

        """
        service = self._get_service_header(service_id)

        payload={}
        headers = self._build_authentication_header()

        url = f"{self.base_url}/services/{service_id}/description"
        response = requests.request("GET", url, headers=headers, data=payload)
        response.raise_for_status()
        service_description = json.loads(response.text)
        service_parameters = service_description["processDescription"]["input"]
        service_parameters = [x for x in service_parameters if not x["identifier"].startswith("TRIGGERING")]
        service_parameters = [x for x in service_parameters if x["identifier"] != "AOI"]

        service["input"] = service_parameters

        return service


    def order_service(self,service_id, service_parameters):
        """Trigger service order

        Parameters
        ----------
        service_id : str
            Service ID
        service_parameters : dict
            Service payload

        Returns
        -------
        dict
            Service order info 
        """
        #area, begin, end = self.get_service_parameters(service_id)
        url = f"{self.base_url}/order"

        service_parameters['serviceId'] = "{}".format(service_id)
        
        payload = json.dumps(service_parameters)
        headers = self._build_authentication_header()
        headers['Content-Type'] = 'application/json'

        response = requests.request("POST", url, headers=headers, data=payload)
        response.raise_for_status()
        return json.loads(response.text)


    
    def get_order(self, order_id):
        """Retrieve order information

        Parameters
        ----------
        order_id : int
            Order ID

        Returns
        -------
        dict
        """
        url = f"{self.base_url}/order/{order_id}"
        payload={}
        headers = self._build_authentication_header()
        response = requests.request("GET", url, headers=headers, data=payload)
        response.raise_for_status()
        return json.loads(response.text)
    
    def get_order_products(self, order_id):
        """Retrieve list of order products

        Parameters
        ----------
        order_id : int
            Order ID

        Returns
        -------
        List
        """
        url = f"{self.base_url}/order/{order_id}/outputs"
        payload={}
        headers = self._build_authentication_header()
        response = requests.request("GET", url, headers=headers, data=payload)
        response.raise_for_status()
        return json.loads(response.text)
